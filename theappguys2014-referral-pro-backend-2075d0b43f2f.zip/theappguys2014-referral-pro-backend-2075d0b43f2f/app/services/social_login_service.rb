class SocialLoginService
  require 'net/http'
  require 'net/https'
  require 'open-uri'
  PASSWORD_DIGEST = SecureRandom.hex(10)
  APPLE_PEM_URL = 'https://appleid.apple.com/auth/keys'

  def initialize(provider, token, type, fcm_token)
    @token = token
    @provider = provider.downcase
    @type = type
    @fcm_token = fcm_token
  end

  def social_login
    send("#{@provider}_signup", @token)
  end

  def google_signup(token)
    @uri = URI("https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=#{token}")
    signup_response
  end

  def facebook_signup(token)
    @uri = URI("https://graph.facebook.com/v13.0/me?fields=name,email&access_token=#{token}")
    signup_response
  end

  def apple_signup(token)
    jwt = token
    begin
      header_segment = JSON.parse(Base64.decode64(jwt.split(".").first))
      alg = header_segment["alg"]
      kid = header_segment["kid"]
      apple_response = Net::HTTP.get(URI.parse(APPLE_PEM_URL))
      apple_certificate = JSON.parse(apple_response)
      keyHash = ActiveSupport::HashWithIndifferentAccess.new(apple_certificate["keys"].select { |key| key["kid"] == kid }[0])
      jwk = JWT::JWK.import(keyHash)
      token_data = JWT.decode(jwt, jwk.public_key, true, { algorithm: alg })[0]
    rescue StandardError => e
      return e.as_json
    end

    data = token_data.with_indifferent_access
    user = create_user(data['email'], data['sub'], data, data['name'], data['image'])
    if @fcm_token.present?
      user.mobile_devices.find_or_create_by(mobile_token: @fcm_token)
    end 
    token_apple = Warden::JWTAuth::UserEncoder.new.call(user, @type.to_sym, nil).first
    image_url = Rails.application.routes.url_helpers.url_for(user.image) rescue nil
    [user, token_apple, image_url]
  end

  private

  def create_user(email, provider_id, response, name, image)
    if (resource = @type.capitalize.constantize.find_by(email: email))
      resource
    else
     user = @type.capitalize.constantize.create(
            email: response['email'],
            name: response['name'],
            password: PASSWORD_DIGEST,
            password_confirmation: PASSWORD_DIGEST
        )
        if image.present?

          download = URI.open(image)
          filename = "profile-#{user.id}-picture"
          user.image.attach(io:download, filename: filename, content_type: download.content_type)
        end
        user
    end
  end

  def signup_response
    response = Net::HTTP.get_response(@uri)
    return JSON.parse(response.body) if response.code != '200'
    json_response = JSON.parse(response.body)
    user = create_user(
           json_response['email'],
           json_response['sub'],
           json_response,
           json_response['name'],
           json_response['profile_image']
        )
    if @fcm_token.present?
      user.mobile_devices.find_or_create_by(mobile_token: @fcm_token)
    end 
    user_token = Warden::JWTAuth::UserEncoder.new.call(user, @type.to_sym, nil).first
    image_url = Rails.application.routes.url_helpers.url_for(user.image) rescue nil
    [user, user_token, image_url]
  end
end
