class TwilioService

  def initialize(phone_number, otp, company, contact_name, user_name, industry_name )
    @phone_number = phone_number
    @otp = otp
    @company = company
    @contact_name = contact_name
    @user_name = user_name
    @industry_name = industry_name
    @twilio_sender_number = ENV['TWILIO_PHONE_NUMBER']
    @client = Twilio::REST::Client.new(ENV['TWILIO_ACCOUNT_SID'], ENV['TWILIO_AUTH_TOKEN'])
  end

  def send_otp
    begin
      response = @client.messages.create(
       from: @twilio_sender_number,
       to: @phone_number,
       body: "Referral Pro verification code is #{@otp}."
     )
      return true
    rescue
      return false
    end
  end

  def send_invite
    response = @client.messages.create(
      from: @twilio_sender_number,
      to: @phone_number,
      body: "You've been added to #{@company}'s team on The Referral Pro app. You can download the app for apple and android. Register today to start sending and receiving referrals."
    )
  end

  def send_referral
     response = @client.messages.create(
       from: @twilio_sender_number,
       to: @phone_number,
       body: "Hey, #{@contact_name}, you asked that I refer you a #{@industry_name} Contractor that I trust. The #{@industry_name}, #{@user_name} is my preferred #{@industry_name} Contractor. Please be on the look out for their call, as they will be calling to schedule a time to see how best they can service you. Thank you for trusting me in connecting you with a right #{@industry_name} Contractor. Thanks and have a great day."
     )

   end

  def send_referral_assign
    response = @client.messages.create(
      from: @twilio_sender_number,
      to: @phone_number,
      body: "Thank you, #{@user_name}, for making the connection and trusting us to take care of your friends and family. #{@contact_name}, we will be in touch soon to see how best we may serve you. Talk Soon!"
    )
  end
end
