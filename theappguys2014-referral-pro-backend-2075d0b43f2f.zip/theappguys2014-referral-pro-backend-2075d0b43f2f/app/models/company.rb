class Company < ApplicationRecord
  devise :database_authenticatable,
         :recoverable, :registerable,
         :jwt_authenticatable,
         jwt_revocation_strategy: JwtDenylist
  
  self.skip_session_storage = [:http_auth, :params_auth]
  self.per_page = 25

  has_one_attached :image

  has_many :referral_assigns, as: :assignable, dependent: :destroy
  has_many :referral_assignments, class_name: 'ReferralAssign', foreign_key: 'company_id', dependent: :destroy
  has_many :referrals, as: :referrable, dependent: :destroy
  has_many :users, dependent: :nullify
  has_many :partners, as: :partnerable, dependent: :destroy
  has_many :invites, dependent: :destroy
  has_many :notifications, as: :notifiable, dependent: :destroy
  has_many :mobile_devices, as: :devicable, dependent: :destroy
  has_many :transactions, dependent: :destroy
  has_many :cards, dependent: :destroy
  
  belongs_to :industry, optional: true

  validates :phone_number, uniqueness: true, if: :phone_number
  validates :email, uniqueness: true
  # validates :stripe_customer_id, uniqueness: true
  
  # before_validation :create_stripe_reference, on: :create

  after_create :generate_otp, if: :phone_number
  after_destroy :delete_company_as_partnered

  def generate_otp
    otp = (SecureRandom.random_number(9e3) + 1e3).to_i
    if ENV['USE_TWILIO'] == '0' 
      message = TwilioService.new(self.phone_number, otp, nil, nil, nil, nil).send_otp
      raise 'Invalid phone number' unless message
    end
    self.update(otp: otp, otp_expiry:(Time.current + 2.minutes))
  end

  def create_stripe_reference
    response = Stripe::Customer.create(email: email)
    self.stripe_customer_id = response.id
  end

  def delete_company_as_partnered
    partners = Partner.where(partnered_type: "Company", partnered_id: self.id)
    partners.destroy_all
  end
end