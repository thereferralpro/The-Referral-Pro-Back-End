class ReferralAssign < ApplicationRecord
  belongs_to :company
  belongs_to :referral, optional: true
  belongs_to :assignable, polymorphic: true

  validates :phone_number, presence: true
end