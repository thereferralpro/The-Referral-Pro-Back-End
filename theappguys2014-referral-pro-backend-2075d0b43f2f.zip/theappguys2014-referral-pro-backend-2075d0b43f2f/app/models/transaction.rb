class Transaction < ApplicationRecord
  belongs_to :company
end
