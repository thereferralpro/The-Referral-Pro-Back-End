class Notification < ApplicationRecord
  belongs_to :notifiable, polymorphic: true

  after_create :push_notifications

  def push_notifications
    require 'fcm'
    fcm_client = FCM.new(ENV['FIREBASE_SECRET_KE'])
    options = { priority: 'high',
                notification: { body: self.body}
             }
    registration_ids = if notifiable_type == 'User'
                        User.find_by(id: self.notifiable_id).mobile_devices.pluck(:mobile_token)
                       else
                        Company.find_by(id: self.notifiable_id).mobile_devices.pluck(:mobile_token)
                       end
    registration_ids.each do |registration_id|
      puts fcm_client.send(registration_id, options)
    end
  end
end
