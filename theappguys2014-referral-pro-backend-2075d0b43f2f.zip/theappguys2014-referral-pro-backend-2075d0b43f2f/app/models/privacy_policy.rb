class PrivacyPolicy < ApplicationRecord


end