class Referral < ApplicationRecord
  belongs_to :referrable_person, class_name: 'User', foreign_key: 'referrable_person_id'
  belongs_to :referrable, polymorphic: true
  has_one :referral_assign
  has_one_attached :contact_image

  enum status: %i[created scheduled in_progress sold contact_initiated no_oportunity]

  scope :filter_by_status, -> (status) { where status: status }

  validates :contact_number, presence: true
end