class Invite < ApplicationRecord
  belongs_to :company

  validates :phone_number, presence: true

  enum status: %i[created accepted rejected]
end