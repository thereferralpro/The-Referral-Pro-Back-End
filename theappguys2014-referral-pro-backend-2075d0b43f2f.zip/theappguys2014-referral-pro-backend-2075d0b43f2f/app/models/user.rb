class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable,
         :jwt_authenticatable, jwt_revocation_strategy: JwtDenylist

  self.skip_session_storage = [:http_auth, :params_auth]
  self.per_page = 25
  
  has_one_attached :image

  belongs_to :company, optional: true
  belongs_to :industry, optional: true

  has_many :referral_assigns, as: :assignable, dependent: :destroy
  has_many :referrals, as: :referrable, dependent: :destroy
  has_many :referred_persons, class_name: 'Referral', foreign_key: 'referrable_person_id', dependent: :destroy
  has_many :partners, as: :partnerable, dependent: :destroy
  has_many :notifications, as: :notifiable, dependent: :destroy
  has_many :mobile_devices, as: :devicable, dependent: :destroy

  validates :phone_number, uniqueness: true, if: :phone_number
  after_create :generate_otp, if: :phone_number
  
  before_destroy :delete_referral_assigns
  after_destroy :delete_user_as_partnered

  def generate_otp
    otp = (SecureRandom.random_number(9e3) + 1e3).to_i
    if ENV['USE_TWILIO'] == '0'
      message = TwilioService.new(self.phone_number,otp, nil, nil, nil, nil).send_otp
      raise 'Invalid phone number' unless message
    end
    self.update(otp: otp, otp_expiry:(Time.current + 2.minutes))
  end

  private
  def delete_referral_assigns
    ReferralAssign.where(assignable_type: "User", assignable_id: id).destroy_all
  end

  def delete_user_as_partnered
    partners = Partner.where(partnered_type: "User", partnered_id: self.id)
    partners.destroy_all
  end
end