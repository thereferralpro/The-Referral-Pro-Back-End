class Partner < ApplicationRecord
  belongs_to :partnerable, polymorphic: true
  belongs_to :partnered, polymorphic: true
end
