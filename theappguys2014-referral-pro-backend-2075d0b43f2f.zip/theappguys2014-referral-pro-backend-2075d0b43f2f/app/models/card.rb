class Card < ApplicationRecord
  belongs_to :company
  validates :token, presence: true, uniqueness: { message: "Card is already added" }

  before_save :update_default_status

  def update_default_status
    self.default = true if company.cards.count == 0
  end

  default_scope { order('updated_at DESC') }
end