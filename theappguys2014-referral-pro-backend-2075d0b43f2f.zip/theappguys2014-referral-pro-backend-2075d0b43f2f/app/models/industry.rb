class Industry < ApplicationRecord
  validates :name, presence: true
  has_many :users
  has_many :companies
  self.per_page = 25
end