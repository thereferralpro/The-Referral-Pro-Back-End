class MobileDevice < ApplicationRecord
  belongs_to :devicable, polymorphic: true
end