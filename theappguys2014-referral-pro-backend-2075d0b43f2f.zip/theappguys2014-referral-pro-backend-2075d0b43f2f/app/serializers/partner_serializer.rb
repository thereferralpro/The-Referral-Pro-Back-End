class PartnerSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers

  attributes :id, :partner, :partner_name, :partnerable_id, :partnerable_type, :partnered_id, :partnered_type, 
             :created_at, :updated_at, :partner_industry, :image

  def partner_name
    partner.name rescue ""
  end

  def partner_industry
    partner.industry rescue ""
  end

  def partner
    if object.partnered_type.downcase == "user"
      User.find_by(id: object.partnered_id)
    else
      Company.find_by(id: object.partnered_id)
    end
  end

  def image
    if object.partnered_type.downcase == "user"
      partnered = User.find_by(id: object.partnered_id)
      partnered.image.attached? ?  url_for(partnered.image) : '' 
    else
      partnered = Company.find_by(id: object.partnered_id)
      partnered.image.attached? ?  url_for(partnered.image) : ''
    end
  end
end
