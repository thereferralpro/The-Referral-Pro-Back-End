class UserSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers

  attributes :id, :name, :email, :phone_number, :otp, :otp_expiry, :industry, :company_id, :company_code,
             :created_at,:updated_at, :is_suspended, :verified, :description, :image, :is_partner

  def image
    object.image.attached? ?  url_for(object.image) : '' if object.image.attached?
  end

  def is_partner
    Partner.where(
      partnerable_id: current_user.id, partnerable_type: current_user.class.name,
      partnered_id: object.id).present? ? true : false
  end

  def current_user
    scope
  end
end
