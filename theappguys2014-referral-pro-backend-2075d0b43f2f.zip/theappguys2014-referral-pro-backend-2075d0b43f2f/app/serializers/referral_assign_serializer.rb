class ReferralAssignSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers
  attributes :id, :company_id, :phone_number, :contact_name, :assignable_id, :assignable_type, :referral_id,:status,
             :created_at, :updated_at, :referral_assigned_company, :referral_assign_person, :image
  
  def referral_assigned_company
    referred_person = Company.find_by_id(object.company_id)
  end

  def referral_assign_person
    if object.assignable_type == "Company"
      referrable_person = Company.find_by_id(object.assignable_id)
    else
      referrable_person = User.find_by_id(object.assignable_id)
    end
  end

  def status
    if object.referral_id.present?
      referral = Referral.find_by(id: object.referral_id)
      referral.status
    else
      status = "created"
    end
  end

  def image
    referred_person = Company.find_by_id(object.company_id)
    referred_person.image.attached? ?  url_for(referred_person.image) : '' 
  end
end
