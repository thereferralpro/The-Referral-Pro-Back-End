class InviteSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers
  attributes :id, :name, :company_id, :company_name, :created_at, :updated_at, :industry, :image, :title

  def image
    company.image.attached? ?  url_for(company.image) : ''
  end

  def industry
    company.industry
  end

  def company_name
    company.name
  end

  def company
    Company.find_by(id: object.company_id)
  end
end
