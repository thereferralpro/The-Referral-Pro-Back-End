class TeamSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers

  attributes :id,:email, :name, :company_id, :created_at, :updated_at, :phone_number,
             :verified, :company_code, :description, :industry,:image

  def image
    object.image.attached? ?  url_for(object.image) : ''
  end
end
