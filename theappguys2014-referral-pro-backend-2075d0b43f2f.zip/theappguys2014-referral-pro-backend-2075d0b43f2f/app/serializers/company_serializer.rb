class CompanySerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers

  attributes :id, :email, :created_at, :updated_at, :industry, :name, :website, :address,
              :service_area, :phone_number, :otp, :otp_expiry, :verified, :industry_id,:description, :image, :is_partner
  def image
    object.image.attached? ?  url_for(object.image) : '' if object.image.attached?
  end

  def is_partner
    begin
      Partner.where(
        partnerable_id: current_company.id, 
        partnerable_type: current_company.class.name,
        partnered_id: object.id
      ).present? ? true : false
    rescue => exception
      false
    end
  end

  def current_company
    scope
  end
end
