class SearchTeamSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers

  attributes :id,:email, :name, :company_id, :phone_number, :created_at, :updated_at,
             :verified, :company_code, :description, :industry, :image

  def image
    object.image.attached? ?  url_for(object.image) : ''
  end
end
