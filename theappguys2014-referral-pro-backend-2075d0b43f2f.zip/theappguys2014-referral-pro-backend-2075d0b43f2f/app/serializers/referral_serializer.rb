class ReferralSerializer < ActiveModel::Serializer
  include Rails.application.routes.url_helpers
  attributes :id, :contact_name, :contact_number, :contact_image, :title, :status, :created_at, :updated_at, 
             :referrable_person_id, :referred_person,:referrable_id, :referrable_type, :referrable_person, :image

  def referred_person
   referred_person = User.find_by_id(object.referrable_person_id)
  end

  def referrable_person
    if object.referrable_type == "Company"
       referrable_person = Company.find_by_id(object.referrable_id)
    else
      referrable_person = User.find_by_id(object.referrable_id)
    end
  end

  def contact_name
    object.contact_name
  end

  def contact_number
    object.contact_number
  end

  def contact_image
    object.contact_image.attached? ? url_for(object.contact_image): ''
  end

  def image
    if object.referrable_person.class.name == "Company"
      referrable_person = Company.find_by_id(object.referrable_person_id)
      referrable_person.image.attached? ?  url_for(referrable_person.image) : '' 
    else
      referrable_person = User.find_by_id(object.referrable_person_id)
      referrable_person.image.attached? ?  url_for(referrable_person.image) : '' 
    end 
  end
end