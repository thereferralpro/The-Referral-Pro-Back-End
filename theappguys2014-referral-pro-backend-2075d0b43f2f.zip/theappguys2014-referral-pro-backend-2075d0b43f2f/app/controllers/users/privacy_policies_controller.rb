class Users::PrivacyPoliciesController < ApiController

  before_action :find_policy, only:[:update_policy]

  def index
   @policy = PrivacyPolicy.first
   render json: { message: "privacy policy", privacy_policy: @policy }
  end

  def create_policy
    @policy = PrivacyPolicy.create(policy_params)
    render json: { privcy_policy: @policy}
  end

  def update_policy
    @policy.update(policy_params)
    render json: { message: "Updated Policy", policy: @policy}
  end

  private

  def policy_params
   params.permit(:id, :policy)
  end

  def find_policy
    @policy = PrivacyPolicy.find_by(id: params[:id])
  end
end