class Users::PartnersController < ApiController
  before_action :authenticate_user!

  def create_partner
    if params[:partnered_type].downcase == "user" && params[:partnered_id].to_i == current_user.id
      render json: { message: "User cannot add yourself as a partner." }
    elsif Partner.find_by(partnerable_id: current_user.id, partnered_id: params[:partnered_id], partnered_type: params[:partnered_type].capitalize).present?
      render json: { message: "User already has this partner." }
    elsif current_user.present? && params[:partnered_type].downcase == "company" && Company.find_by(id: params[:partnered_id]).present?
      @partner = current_user.partners.create(partnered_id: params[:partnered_id], partnered_type: params[:partnered_type].capitalize)
      render json: @partner
    elsif current_user.present? && params[:partnered_type].downcase == "user" && User.find_by(id: params[:partnered_id]).present?
      @partner = current_user.partners.create(partnered_id: params[:partnered_id], partnered_type: params[:partnered_type].capitalize)
      render json: @partner
    else
      render json: { message: "User/Company is not present." }
    end
  end

  def my_partners
    @partners = current_user.partners
    render json: {
      partners: ActiveModel::Serializer::CollectionSerializer.new(@partners, serializer:PartnerSerializer)
    }
  end

  def user_invites
   invites =  Invite.where(phone_number: current_user.phone_number, status: "created")
   render json: {
    received_invites: ActiveModel::Serializer::CollectionSerializer.new(invites, serializer: InviteSerializer)}
  end

  def accept_invites
    invite =  Invite.find_by(id: params[:id])
    return render json: { message: "Invite not found agains given id" } unless invite.present?
    invite.update(status: "accepted")
    current_user.update(company_id: invite.company_id)
    render json: { message: "Invite accepted"}
  end

  def decline_invites
    invite =  Invite.find_by(id: params[:id])
    return render json: { message: "Invite not found agains given id" } unless invite.present?
    invite.update(status: "rejected")
    render json: { message: "Invite rejected"}
  end

  def get_user
    render json: {
      user: current_user,
      profile_image: current_user.image.attached? ? url_for(current_user.image) : ''
    }
  end

  def delete_user
    current_user.destroy
    render json: { message: "User deleted successfully"}
  end

  def save_fcm_token
    if params[:token].present?
      token = current_user.mobile_devices.find_or_create_by(mobile_token: params[:token])
      render json: { message: "fcm token successfully saved", token: token }
    end  
  end
end