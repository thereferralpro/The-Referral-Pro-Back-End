class Users::ResetPasswordsController < ResetPasswordsController
  before_action :user_find

  private
  def user_find
    @current_user = User.find_by(phone_number: params[:phone_number])
    define_resource(@current_user)
  end
end