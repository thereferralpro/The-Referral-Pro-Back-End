class Users::RegistrationsController < Devise::RegistrationsController
  respond_to :json

  def create
    begin
      super
      invite = Invite.find_by(phone_number: params[:user][:phone_number])
      if invite.present?
        Notification.create(
          # body: "Your team member #{resource.name} is registered",
          body: "Your team member #{resource.name} has successfully registered.",
          notifiable_id: invite.company.id,
          notifiable_type: "Company"
        )
    end
    rescue => e   
      return render json: { message: e.message }, status: :unprocessable_entity
    end    
  end

  def update
    resource.update(account_update_params)
    render json: {
      message:  "Informations updated successfully",
      user: resource,
      profile_image: resource.image.attached? ? url_for(resource.image) : ''
    }
  end

  private

  def respond_with(resource, _opts = {})
    resource.persisted? ? register_success : register_failed
  end

  def register_success
    render json: {
      message: 'Signed up successfully.',
      data: resource,
      profile_image: resource.image.attached? ? url_for(resource.image) : '',
      token: request.env['warden-jwt_auth.token']
    }
  end

  def register_failed
    render json: { status: "Signed up failure.", message: resource.errors.full_messages }
  end

  def sign_up_params
    params.require(:user).permit(:email, :password, :password_confirmation, :phone_number, 
                                 :name, :image, :description, :industry_id
    )
  end

  def account_update_params
    params.require(:user).permit(:name, :image, :description, :company_code)
  end
end