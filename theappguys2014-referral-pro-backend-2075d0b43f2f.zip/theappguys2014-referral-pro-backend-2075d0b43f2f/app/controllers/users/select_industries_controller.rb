class Users::SelectIndustriesController < SelectIndustriesController
  before_action :authenticate_user!
  before_action :assign_resource

  private
  def assign_resource
    define_resource(current_user)
  end
end