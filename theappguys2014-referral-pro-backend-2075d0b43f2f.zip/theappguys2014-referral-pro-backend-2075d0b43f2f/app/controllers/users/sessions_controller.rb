class Users::SessionsController < Devise::SessionsController
  respond_to :json

  def create
    if !current_user
      log_in_failure
    elsif current_user.is_suspended == true
      render json: { message: "User is suspended" }
    elsif !current_user.verified
      render json: { message: "User not verified" }
    else
      super
    end
  end

 
  private
  
  def respond_with(resource, _opts = {})
    render json: {
      message: 'Logged.',
      user: resource,
      profile_image: resource.image.attached? ? url_for(resource.image) : '',
      token: request.env['warden-jwt_auth.token']
    }, status: :ok
  end

  def respond_to_on_destroy
    current_user ? log_out_success : log_out_failure
  end

  def log_out_success
    render json: { message: "Logged out." }, status: :ok
  end

  def log_out_failure
    render json: { message: "Logged out failure."}, status: :unauthorized
  end

  def log_in_failure
    render json: { message: "Logged in failure" }, status: :unauthorized
  end
end