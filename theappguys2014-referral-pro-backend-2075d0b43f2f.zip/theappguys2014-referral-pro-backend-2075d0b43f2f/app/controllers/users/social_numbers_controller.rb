class Users::SocialNumbersController < ApiController
  before_action :authenticate_user!

  def add_phone_number
    if User.find_by(phone_number: params[:phone_number]).present?
      render json: { message: "phone number is already belongs to another user"}
    elsif params[:phone_number].present?
      otp = (SecureRandom.random_number(9e3) + 1e3).to_i
      if ENV['USE_TWILIO'] == '0'  
        message = TwilioService.new(params[:phone_number], otp, nil, nil, nil, nil).send_otp
        raise 'Invalid phone number' unless message
      end
      current_user.update(otp: otp, otp_expiry:(Time.current + 2.minutes))
      render json: { message: "Please verify you phone number"}
    end
  end

  def resend_otp
    if params[:phone_number].present?
      otp = (SecureRandom.random_number(9e3) + 1e3).to_i
      if ENV['USE_TWILIO'] == '0'  
        message = TwilioService.new(params[:phone_number], otp, nil, nil, nil, nil).send_otp
        raise 'Invalid phone number' unless message
      end
      current_user.update(otp: otp, otp_expiry:(Time.current + 2.minutes))
      render json: { message: "Otp sent successfully", user: current_user}
    else
      render json: { message: "Please enter number for verification"}
    end
  end

  def otp_verification
    return render json: { message: "User not found " } unless current_user.present?
    if current_user.otp == params[:otp].to_i && current_user.otp_expiry >= Time.current && params[:otp].present?
      current_user.update(verified: true)
     if current_user.verified == true 
      current_user.update(phone_number: params[:phone_number])
      render json: { message: "Phone number saved successfully"}
     end
    else
      return render json: { message: 'otp not valid or present' }
    end
  end
end