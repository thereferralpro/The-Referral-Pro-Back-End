class Users::ReferralsController < ApiController
  before_action :authenticate_user!
  before_action :validate_referral_params, only: :create_referral

  def industry_user
    @user = User.where.not(company_id: nil).where(industry_id: params[:industry_id])
    @users = @user.where.not(id: current_user.id)
    @company = Company.where(industry_id: params[:industry_id])
    render json:{
     users: ActiveModel::Serializer::CollectionSerializer.new(
      @users,
      each_serializer: UserSerializer,
      scope: current_user
    ),
     companies: ActiveModel::Serializer::CollectionSerializer.new(
      @company,
      each_serializer: CompanySerializer,
      scope: current_user
    ),
    }
  end

  def create_referral
    phone_number = sync_contact(params[:contact_number])
    if params[:type] == 'company'
      begin
        ActiveRecord::Base.transaction do
          @assigns = current_user.referral_assigns.create(
            company_id: params[:referrable_person_id],
            phone_number: phone_number,
            contact_name: params[:contact_name]
          )
          @referrable_company = Company.find_by(id: @assigns.company_id)
          TwilioService.new(@assigns.phone_number, nil, nil, params[:contact_name],current_user.name, nil).send_referral_assign
          TwilioService.new(current_user.phone_number, nil, nil, params[:contact_name],current_user.name, nil).send_referral_assign
          TwilioService.new(@referrable_company.phone_number, nil, nil, params[:contact_name],current_user.name, nil).send_referral_assign
        end
       rescue => e
        return render json: { message: e.error_message }
      end
        @referrable_person = Company.find_by(id: params[:referrable_person_id])
        @referrable_person_name = @referrable_person.name
        @industry_name = @referrable_person.industry.name

        Notification.create(
          body: "Your referral to #{@industry_name} #{@referrable_person_name} assigned successfully",
          notifiable_id: current_user.id, notifiable_type: current_user.class.name
        )

        Notification.create(
          # body: "You have been assigned a referral by #{current_user.name} for #{@industry_name} job",
          body: "Your company has received a new referral. You can now assign this referral to a team member.",
          notifiable_id: @referrable_person.id, notifiable_type: @referrable_person.class.name
        )
        render json: @assigns
    else
      params[:contact_number] = phone_number
      begin
        ActiveRecord::Base.transaction do
          @referral = current_user.referrals.create(referral_params.merge(status: :created))
          @user = User.find_by(id: params[:referrable_person_id])
          TwilioService.new(@referral.contact_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral
          TwilioService.new(@referral.contact_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral_assign
          TwilioService.new(current_user.phone_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral_assign
          TwilioService.new(@user.phone_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral_assign
        end
      rescue => e
        return render json: { message: e.error_message }
      end
      @referrable_person = User.find_by(id: params[:referrable_person_id])
      @referrable_person_name = @referrable_person.name
      @industry_name = @referrable_person.industry.name

      Notification.create(
        body: "Your referral to #{@industry_name} #{@referrable_person_name} sent successfully",
        notifiable_id: current_user.id, notifiable_type: current_user.class.name
      )

      Notification.create(
        # body: "You have been assigned a referral by #{current_user.name} for #{@industry_name} job",
        body: "You have a new referral.",
        notifiable_id: @referrable_person.id, notifiable_type: @referrable_person.class.name
      )
      if @referrable_person.company_id.present?
        Notification.create(
          # body: "Your team member #{@referrable_person_name} has received a new referral from #{current_user.name} for #{@industry_name} job",
          body: "Your team member #{@referrable_person_name} received a new referral",
          notifiable_id: @referrable_person.company_id, notifiable_type: 'Company'
        )
      end
      render json: @referral
    end
  end

  def sent_referral
    referrals = current_user.referrals
    var = current_user.referral_assigns.pluck(:referral_id)
    if var.present?
      referral_assigns = Referral.where(id: var).where.not(id: referrals.ids)
      all_referral = referrals + referral_assigns
      all_referral = all_referral.uniq
      return render json: {
        referrals: ActiveModel::Serializer::CollectionSerializer.new(
         all_referral,
          each_serializer: ReferralSerializer
        ),
        referral_assgins: ActiveModel::Serializer::CollectionSerializer.new(
          current_user.referral_assigns.where(referral_id: nil), 
          each_serializer: ReferralAssignSerializer
        )
      }
    end

    render json: {
      referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer)
    }
  end

  def received_referral
    if current_user.company_id == nil
      render json: { message: "For receiving referrals you should belongs to a company"}
     else
      referrals = current_user.referred_persons
      render json: referrals
    end
  end

  def filter_referrals
    if params[:status].present?
      referrals = current_user.referred_persons.filter_by_status(params[:status])
    else
      referrals = current_user.referred_persons
    end

    render json: {
      referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer)
    }
  end

  def sort_referrals
    if params[:sort_by] == "newest_received"
      sorted_referrals = current_user.referred_persons.order("created_at DESC")

    render json:{
      sorted_referrals: ActiveModel::Serializer::CollectionSerializer.new(
        sorted_referrals,
        each_serializer: ReferralSerializer
        )
      }
    else params[:sort_by] == "oldest_received"
      referrals = current_user.referred_persons.order("created_at ASC")

    render json:{
      sorted_referrals: ActiveModel::Serializer::CollectionSerializer.new(
        referrals,
        each_serializer: ReferralSerializer
        )
      }
    end
  end

  def update_referral_status
    referral = current_user.referred_persons.find_by(id: params[:id])
    return render json: { message: "User received referral not found against given id" } unless referral.present?
    referral.update(status_params)
    if params[:status] == 'sold' || params[:status] == 'no_oportunity' || params[:status] == 'scheduled'
      Notification.create(
        # body: "Referral status changed to #{params[:status]}",
        body: "A referral you sent has been closed as #{params[:status]}", 
        notifiable_id: referral.referrable_id, notifiable_type: 'User'
      )
    end
    if current_user.company && ['sold', 'no_oportunity', 'in_progress', 'scheduled', 'contact_initiated'].include?(params[:status])
      Notification.create(
        # body: "Your team member #{current_user.name} referral status changed to #{params[:status]}",
        body: "Your team member #{current_user.name} referral status for #{current_user.industry.name} is now changed to #{params[:status]}",
        notifiable_id: current_user.company.id, notifiable_type: 'Company'
      )
    end
    render json: { message: "Status updated successfully"}
  end

  private

  def validate_referral_params
    return render json: { message: "Type not found" } unless ['company', 'user'].include? params[:type]

    @type = params[:type].capitalize
    referred_person = @type.constantize.find_by(id: params[:referrable_person_id])

    if referred_person.blank?
      render json: { message: "#{@type} against this id is not present" }
    elsif params[:referrable_person_id].to_i == current_user.id && @type == "User"
      render json: { message: "You cannot refer yourself"}
    elsif current_user.referrals.where(referrable_person: referred_person, contact_number: params[:contact_number]).any? && @type == "User"
      render json: { message: "#{@type} is already referred" }
    elsif referred_person.industry == nil
      render json: { message: "You should be industry professional"}
    end
  end

  def referral_params
    params.permit(:referrable_person_id, :contact_name, :contact_number, :contact_image)
  end

  def status_params
    params.permit(:id, :status, :title)
  end
end
