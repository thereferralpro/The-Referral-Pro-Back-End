class Users::NotificationsController < ApiController
  before_action :authenticate_user!

  def user_or_company_notifications
   if current_user.present?
    render json: { message: "User all notifications", notifications: current_user.notifications }
   else
    render json: { message: "authentication failed."}
   end
  end

  def destroy_notification
    if current_user.present?
      @notification = Notification.find_by(id: params[:id])
      if @notification.present?
        @notification.destroy
        render json: { message: "Notification successfully deleted" }
      else
        render json: { message: "Notification not found." }
      end
    else
      render json: { message: "authentication failed." }
    end   
  end

  def destroy_mobile_devices
    if current_user.present?
      mobile_devices = MobileDevice.where(devicable_id: current_user.id)
      if mobile_devices.present?
        current_user.mobile_devices.destroy_all
        render json: { message: "mobile devices successfully destroyed" }
      else
        render json: { message: "user not have any mobile device" }
      end
    else
      render json: { message: "something went wrong" }
    end
  end
end