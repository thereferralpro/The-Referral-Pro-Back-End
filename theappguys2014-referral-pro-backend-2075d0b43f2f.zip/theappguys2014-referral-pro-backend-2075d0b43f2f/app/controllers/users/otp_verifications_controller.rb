class Users::OtpVerificationsController < ApiController
  before_action :find_user

  def verify_otp
    return render json: { message: "User not found against given number" } unless @current_user.present?
    if @current_user.otp == params[:otp].to_i && @current_user.otp_expiry >= Time.current && params[:otp].present?
      @current_user.update(verified: true)
      return render json: { message: "otp verified" }
    else
      return render json: { message: 'otp not valid or present' }
    end
  end

  private

  def find_user
    @current_user = User.find_by(phone_number: params[:phone_number])
  end
end