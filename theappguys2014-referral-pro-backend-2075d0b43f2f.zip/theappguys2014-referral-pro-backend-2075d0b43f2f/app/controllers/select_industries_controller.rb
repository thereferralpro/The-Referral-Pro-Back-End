class SelectIndustriesController < ApiController
  def all_industry
    render json: { message:"Available Industries", industries: Industry.all }
  end

  def industry_selection
    if industry = Industry.find_by(id: params[:industry_id]).present?
      @resource.update(industry_id: params[:industry_id])
      render json: @resource
    else
      render json: {message: "This industry is not present"}
    end
  end

  def search_industry
    @resource = Industry.ransack("name_cont": params[:name])
    @industries = @resource.result(distinct: true)
    render json: { message: "Search results", results: @industries}
  end

  protected

  def define_resource(resource)
    @resource = resource
  end
end