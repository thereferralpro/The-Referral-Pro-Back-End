class Admins::PasswordsController < Devise::PasswordsController
  def new
    super
  end

  def create
    if Admin.last.email == params[:admin][:email]
      $otp = 4.times.map{rand(10)}.join
      super
    else
      redirect_to new_admin_password_path
      flash[:alert] = "Invalid Email"
    end 
  end

  def update
    super
  end

  def edit
    super
  end
end
