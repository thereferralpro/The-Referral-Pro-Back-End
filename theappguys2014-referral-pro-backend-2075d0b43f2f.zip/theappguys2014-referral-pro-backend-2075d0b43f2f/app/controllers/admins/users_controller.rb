class Admins::UsersController < ApplicationController
  before_action :authenticate_admin!
  before_action :set_user, only: [:show, :edit, :update, :destroy, :user_bio, :user_sent_referrals, :user_received_referrals]

  # GET /users
  def index
    @users = User.all
  end

  # GET /users/1
  def show
  end

  # GET /users/new
  def new
    @user = User.new
  end

  # GET /users/1/edit
  def edit
    if @user.phone_number != nil
      # @country_code = @user.phone_number.slice(1,2)
      @user.phone_number= @user.phone_number.slice(2,@user.phone_number.length)
    end
  end

  # POST /users
  def create
    @user = User.new(user_params.except(:country_code))
    @user.phone_number = '+' + params[:user][:country_code] + params[:user][:phone_number]
    begin
      if @user.save
        redirect_to manage_user_admins_manage_users_path, alert: 'User has been created successfully.'
      else
        redirect_to new_admins_user_path
        flash[:alert] = @user.errors.full_messages.to_sentence
      end
    rescue => exception
      redirect_to new_admins_user_path
      flash[:alert] = exception.message
    end
  end

  # PATCH/PUT /users/1
  def update
    if params[:user].include? "name"
      @user.phone_number = '+' + params[:user][:country_code] + params[:user][:phone_number]
      if @user.update(user_params.except(:country_code, :phone_number))
        redirect_to bio_admins_user_path(@user), alert: 'User has been updated successfully.'
      else
        redirect_to edit_admins_user_path(@user.id)
        flash[:alert] = @user.errors.full_messages.to_sentence
      end
    elsif params[:user].include? "bio"
      if @user.update(description: params[:user][:bio])
        redirect_to sent_referrals_admins_user_path(@user), alert: 'User has been updated successfully.'
      else
        redirect_to bio_admins_user_path(@user)
        flash[:alert] = @user.errors.full_messages.to_sentence
      end
    end
  end

  # DELETE /users/1
  def destroy
    @user.destroy
    redirect_to manage_user_admins_manage_users_path, alert: 'User has been deleted successfully.'
  end

  def user_bio
  end

  def user_sent_referrals
    if params[:status].present? && !params[:type].present?
      @user_sent_referrals = @user.referrals.where(status: params[:status])
    else
      @user_sent_referrals = @user.referrals
    end
  end

  def user_received_referrals
    if params[:status].present? && !params[:type].present?
      @user_received_referrals = Referral.where(referrable_person_id: @user.id, status: params[:status])
    else
      @user_received_referrals = Referral.where(referrable_person_id: @user.id)
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_user
      @user = User.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def user_params
      params.require(:user).permit(:name, :email, :password, :country_code, :phone_number, :industry_id, :image)
    end
end
