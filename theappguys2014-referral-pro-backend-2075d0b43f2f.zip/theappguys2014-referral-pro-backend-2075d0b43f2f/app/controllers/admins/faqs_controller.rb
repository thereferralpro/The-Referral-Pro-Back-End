class Admins::FaqsController < ApplicationController
  before_action :authenticate_admin!
  before_action :set_faq, only: [:edit, :show, :update, :destroy, :move]

  def index
   @faqs = Faq.all
  end

  def new
   @faq = Faq.new
  end

  def create
   @faq = Faq.new(faq_params)
   if @faq.save
    redirect_to manage_faq_admins_manage_users_path
    flash[:alert] = "Faq has been created successfully."
   else
    redirect_to new_admins_faq_path
    flash[:alert] = @faq.errors.full_messages.to_sentence
   end
  end

  def edit
  end

  def show
  end

  def update
   if @faq.update(faq_params)
    redirect_to manage_faq_admins_manage_users_path
    flash[:alert] = "Faq has been updated successfully."
   else
    redirect_to admins_faq_admin_faqs_edit_path
    flash[:alert] = @faq.errors.full_messages.to_sentence
   end
  end

  def destroy
   if @faq.destroy
    redirect_to manage_faq_admins_manage_users_path
    flash[:alert] = "Faq has been deleted successfully."
   end
  end

  def move
    @faq.insert_at(params[:position].to_i)
    head :ok
  end

   private

   def set_faq
    if params[:action]=="move"
      @faq = Faq.find(params[:id])
    else
      @faq = Faq.find(params[:faq_id])
    end
   end

   def faq_params
    params.require(:faq).permit(:question, :answer)
   end
  end
