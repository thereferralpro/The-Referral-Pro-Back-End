class Admins::ManageUsersController < ApplicationController
	before_action :authenticate_admin!

	def index
	end

	def already_sign_in
	end

	def manage_faq
		@faqs = Faq.all.order(position: :asc).paginate(page: params[:page])
	end

	def financial_report
		@revenue = Transaction.all.sum(:price)
		@transactions_count = Transaction.count
		if params[:range].present? && params[:range] == "last_week"
			@revenue = Transaction.where("created_at >= ?", 1.week.ago).sum(:price)
			@transactions_count = Transaction.where("created_at >= ?", 1.week.ago).count
			@range = "last_week"
		elsif params[:range].present? && params[:range] == "last_month"
			@revenue = Transaction.where("created_at >= ?", 1.month.ago).sum(:price)
			@transactions_count = Transaction.where("created_at >= ?", 1.month.ago).count
			@range = "last_month"
		elsif params[:range].present? && params[:range] == "all"
			@range = "all"
		else
			@range = nil
		end
		@growth_rate = fetch_business_growth_rate
	end

	def manage_user
		if params[:search_key].present? && !params[:search_key].nil?
			@users = User.all.where('Lower(name) LIKE ?', "%#{params[:search_key].downcase}%").paginate(page: params[:page])
			@search_key = params[:search_key]
			@users_count_for_graph = User.all.count
		else
			if params[:range].present? && params[:range] == "last_week"
				@users = User.where("created_at >= ?", 1.week.ago).paginate(page: params[:page])
				@range = "last_week"
				@users_count_for_graph = @users.count
			elsif params[:range].present? && params[:range] == "last_month"
				@users = User.where("created_at >= ?", 1.month.ago).paginate(page: params[:page])
				@range = "last_month"
				@users_count_for_graph = @users.count
			elsif params[:range].present? && params[:range] == "all"
				@users = User.all.paginate(page: params[:page])
				@range = "all"
				@users_count_for_graph = @users.count
			else
				@users = User.all.paginate(page: params[:page])
				@range = nil
				@users_count_for_graph = @users.count
			end
		end
	end
	
	def companies
		if params[:search_key].present? && !params[:search_key].nil?
			@companies = Company.all.where('Lower(name) LIKE ?', "%#{params[:search_key].downcase}%").paginate(page: params[:page])
			@search_key = params[:search_key]
			@companies_count_for_graph = Company.all.count
		else
			if params[:range].present? && params[:range] == "last_week"
				@companies = Company.where("created_at >= ?", 1.week.ago).paginate(page: params[:page])
				@range = "last_week"
				@companies_count_for_graph = @companies.count
			elsif params[:range].present? && params[:range] == "last_month"
				@companies = Company.where("created_at >= ?", 1.month.ago).paginate(page: params[:page])
				@range = "last_month"
				@companies_count_for_graph = @companies.count
			elsif params[:range].present? && params[:range] == "all"
				@companies = Company.all.paginate(page: params[:page])
				@range = "all"
				@companies_count_for_graph = @companies.count
			else
				@companies = Company.all.paginate(page: params[:page])
				@range = nil
				@companies_count_for_graph = @companies.count
			end
		end
	end

	def show
	end

	private

  def authenticate_admin!
    if admin_signed_in?
      super
    else
      redirect_to new_admin_session_path, :notice => 'You need to sign in or sign up before continuing.'
    end
	end

	def fetch_business_growth_rate
		@current_month_revenue = Transaction.where(created_at: 1.month.ago..DateTime.now).sum(:price)
		@last_month_revenue = Transaction.where(created_at: 2.month.ago..1.month.ago).sum(:price)
		if @last_month_revenue != 0 
			@growth_rate_percentage = (((@current_month_revenue - @last_month_revenue) / @last_month_revenue.to_f) * 100).round
		else
			@growth_rate_percentage = 0
		end
	end
end
