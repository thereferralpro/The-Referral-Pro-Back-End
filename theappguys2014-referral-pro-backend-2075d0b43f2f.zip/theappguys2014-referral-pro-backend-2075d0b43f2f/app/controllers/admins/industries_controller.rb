class Admins::IndustriesController < ApplicationController
  before_action :authenticate_admin!
  before_action :set_industry, only: [:edit, :show, :update, :destroy]

  def index
    if params[:search_key].present? && !params[:search_key].nil?
			@industries = Industry.all.where('Lower(name) LIKE ?', "%#{params[:search_key].downcase}%").paginate(page: params[:page])
			@search_key = params[:search_key]
		else
      @industries = Industry.all.paginate(page: params[:page])
    end
  end

  def new
   @industry = Industry.new
  end

  def create
   @industry = Industry.new(industry_params)
   if @industry.save
    redirect_to admins_industries_path
    flash[:alert] = "Industry has been created successfully."
   else
    redirect_to new_admins_industry_path
    flash[:alert] = @industry.errors.full_messages.to_sentence
   end
  end

  def edit
  end

  def show
    if params[:type].present? && params[:type]=="companies"
      @industry_companies = @industry.companies
      @industry_users = nil
    else
      @industry_users = @industry.users
      @industry_companies = nil
    end
  end

  def update
   if @industry.update(industry_params)
    redirect_to admins_industries_path
    flash[:alert] = "Industry has been updated successfully."
   else
    redirect_to edit_admins_industry_path
    flash[:alert] = @industry.errors.full_messages.to_sentence
   end
  end

  def destroy
    begin
      if @industry.destroy
        redirect_to admins_industries_path
        flash[:alert] = "Industry has been deleted successfully."
      else
        redirect_to admins_industries_path
        flash[:alert] = @industry.errors.full_messages.to_sentence
      end
    rescue => exception
      redirect_to admins_industries_path
      flash[:alert] = exception.message
    end
    
  end

   private

   def set_industry
      @industry = Industry.find(params[:id])
   end

   def industry_params
    params.require(:industry).permit(:name)
   end
  end
