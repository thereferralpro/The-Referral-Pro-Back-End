class Companies::ReferralAssignsController < ApiController
  before_action :find_user_or_company
  before_action :validate_referral_params, only: :referral_assign

  def referral_assign
    @user = User.find_by(id: params[:user_id])
      @assigned_referral = Referral.create(
        referrable_person_id: params[:user_id],
        referrable_id: @referral_assign.assignable_id,
        referrable_type: @referral_assign.assignable_type,
        contact_name: @user.name,
        contact_number: @user.phone_number
      )
    Notification.create(
      body: "Your referral to #{@user.industry.name} #{@user.name} sent successfully",
      notifiable_id: current_company.id, notifiable_type: current_company.class.name
    )

    Notification.create(
      body: "You have a new referral.",
      notifiable_id: @user.id, notifiable_type: @user.class.name
    )
    if @user.company_id.present? && @user.company_id != current_company.id
      Notification.create(
        body: "Your team member #{@user.name} received a new referral",
        notifiable_id: @user.company_id, notifiable_type: 'Company'
      )
    end
    @referral_assign.update(referral_id: @assigned_referral.id)
    render json: { message: "Referral assigned successfully to user", referral: @assigned_referral}
  end

  private

  def find_user_or_company
    @referral_assign = ReferralAssign.find_by(id: params[:id])
  end

  def validate_referral_params
    referral_assign_person = current_company.users.find_by(id: params[:user_id])

    if referral_assign_person.blank?
      render json: { message: "Team member against this id is not present" }
    elsif @referral_assign.blank?
      render json: {  mmessage: "Assign Referral against this id is not present" }
    end
  end
end