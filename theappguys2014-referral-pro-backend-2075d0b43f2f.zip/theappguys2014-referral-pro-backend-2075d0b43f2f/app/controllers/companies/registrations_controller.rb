class Companies::RegistrationsController < Devise::RegistrationsController
  respond_to :json

  def create
    begin
      super
    rescue => e
      return render json: { message: e.message }, status: :unprocessable_entity
    end
  end

  def update
    resource.update(account_update_params)
    render json: {
      message:  "Informations updated successfully",
      company: resource,
      profile_image: resource.image.attached? ? url_for(resource.image) : ''
    }
  end

  private

  def respond_with(resource, _opts = {})
    resource.persisted? ? register_success : register_failed
  end

  def register_success
    render json: {
      message: 'Signed up successfully.',
      data: resource,
      profile_image: resource.image.attached? ? url_for(resource.image) : '',
      token: request.env['warden-jwt_auth.token']
    }
  end

  def register_failed
    render json: { status: "Signed up failure.", message: resource.errors.full_messages }
  end

  def sign_up_params
    params.require(:company).permit(
      :email, :password, :password_confirmation, :phone_number
    )
  end

  def account_update_params
    params.require(:company).permit(:name, :image, :website, :address, :service_area, :description, :industry_id)
  end
end