class Companies::TransactionsController < ApiController
  before_action :authenticate_company!

  def index
    render json: current_company.transactions
  end

  def create
    transaction = current_company.transactions.new
    if params[:orderId].present?
      transaction.transaction_id = params[:orderId]
      transaction.transaction_date = params[:purchaseTime].to_s + '.0'
      transaction.transaction_receipt = params[:purchaseToken]
      transaction.price = params[:price]
    else
      transaction.transaction_id = params[:transactionId]
      transaction.transaction_date = params[:transactionDate]
      transaction.transaction_receipt = params[:transactionReceipt]
      transaction.price = params[:price]
    end

    transaction.product_id = params[:productId]

    if transaction.save
      render json: { transaction: transaction, message: 'Transaction was successfully created.' }
    else
      render json: { message: 'Something went wrong' }
    end
  end
end
