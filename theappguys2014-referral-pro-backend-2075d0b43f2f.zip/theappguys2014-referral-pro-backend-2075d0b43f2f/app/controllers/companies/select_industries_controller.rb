class Companies::SelectIndustriesController < SelectIndustriesController
  before_action :authenticate_company!
  before_action :assign_resource

  private
  def assign_resource
    define_resource(current_company)
  end
end