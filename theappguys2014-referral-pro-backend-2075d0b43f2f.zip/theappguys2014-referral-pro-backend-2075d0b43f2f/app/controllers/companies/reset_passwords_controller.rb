class Companies::ResetPasswordsController < ResetPasswordsController
  before_action :company_find

  private
  def company_find
    @current_company = Company.find_by(phone_number: params[:phone_number])
    define_resource(@current_company)
  end
end