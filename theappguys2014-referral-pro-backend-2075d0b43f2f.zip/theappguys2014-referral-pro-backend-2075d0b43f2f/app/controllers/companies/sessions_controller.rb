class Companies::SessionsController < Devise::SessionsController
  respond_to :json

  def create
    if !current_company
      log_in_failure
    elsif !current_company.verified
      render json: { message: "Company not verified" }
    else
      super
    end
  end
  
  private

  def respond_with(resource, _opts = {})
    transaction = resource.transactions.order(:created_at).last
    subscription_ended = transaction.present? ? false : true
        
    render json: {
      message: 'Logged In successfully.',
      company: resource,
      profile_image: resource.image.attached? ? url_for(resource.image) : '',
      token: request.env['warden-jwt_auth.token'],
      subscription_ended: subscription_ended
   }, status: :ok
  end

  def respond_to_on_destroy
    current_company ? log_out_success : log_out_failure
  end

  def log_out_success
    render json: { message: "You Logged out ." }, status: :ok
  end

  def log_out_failure
    render json: { message: "Logged out failure."}, status: :unauthorized
  end

  def log_in_failure
    render json: { message: "Logged in failure" }, status: :unauthorized
  end
end
