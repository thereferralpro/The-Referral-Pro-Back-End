class Companies::CardsController < ApiController
  before_action :authenticate_company!

  def add_card
    return render json: {message: "Token is not present"}, status: :unauthorized if (params[:token]).blank?

    customer = get_stripe_customer
    card = create_customer_card(customer)

    if !card[:message].present?
      if ['true', true].include? params[:default] 
        card.company.cards.where.not(id: card.id).update_all(default: false)
        card.update(default: true)
      end
      render json: { card: card, message: "Card has been saved successfully."}
    else
      render json: { message: card[:message] }
    end
  end

  def all_cards
    cards = current_company.cards
    render json: cards
  end

  def delete_card
    if current_company.cards.find_by(id: params[:card_id]).present?
      card = current_company.cards.find_by(id: params[:card_id])
      card.delete
      if current_company.cards.last.present?
        current_company.cards.last.update(default: true) if card.default
        render json: {message: "Card has been deleted successfully!"}
      else
        render json: {message: "Card has been deleted successfully!"}
      end
    else
      render json: {message: "Card is not found!"}, status: :unauthorized
    end
  end

  def edit_card
    cards = current_company.cards
    card = cards.find_by(id: params[:card_id])
    if params[:save_for_future].present?
      return render json: {message: "Token is not present"}, status: :unauthorized if (params[:token]).blank?
      
      current_card = card
      customer = get_stripe_customer
      card = create_customer_card(customer)
      card.company.cards.where.not(id: card.id).update_all(default: false)
      card.update(default: true, card_holder_name: current_card.card_holder_name)

      render json: { card: card, message: "Card has been saved successfully."}
    else
      if card
        card.update(card_holder_name: params[:card_holder_name]) if params[:card_holder_name].present?
        if ['true', true].include? params[:default] 
          cards.where.not(id: card.id).update_all(default: false)
          card.update(default: true)
        end

        render json: { card: card, message: "Card has been updated successfully."}
      else
        render json: {message: "card_id is not present!"}, status: :unauthorized
      end
    end
  end
  
  def company_default_card
    card = current_company.cards.find_by(default: true)
    if card
      render json: card
    else
      render json: { message: "company have not any default card" }, status: 404
    end
  end
  
  private

  def get_stripe_customer
    if current_company.stripe_customer_id.present?
      begin
        customer = Stripe::Customer.retrieve(current_company.stripe_customer_id)
      rescue => e
        return render json: {message: e}
      end  
    else
      customer = Stripe::Customer.create({
        email: current_company.email
      })
      current_company.update(stripe_customer_id: customer.id)
    end

    customer
  end

  def create_customer_card(customer)
    begin
      data =  Stripe::Customer.create_source( customer.id, { source: params[:token] } )
    rescue => e
      return { message: e }
    end
    card_id = data.id
    brand = data.brand
    country = data.country
    expiry = data.exp_year
    cvc = data.last4
    expiry_month = data.exp_month
    card_holder_name = data.name
    city = data.address_city
    card = Card.create( token: card_id, card_holder_name: params[:name], cvc: cvc, expiry: expiry, expiry_month: expiry_month, 
                        brand_name: brand, city: city, country: country, company_id: current_company.id)

    card
  end

end