class Companies::NotificationsController < ApiController
  before_action :authenticate_company!

  def user_or_company_notifications
   if current_company.present?
    render json: { message: "Company all notifications", notifications: current_company.notifications }
   else
    render json: { message: "Authentication failed."}
   end
  end

  def destroy_notification
    if current_company.present?
      @notification = Notification.find_by(id: params[:id])
      if @notification.present?
        @notification.destroy
        render json: { message: "Notification successfully deleted" }
      else
        render json: { message: "Notification not found." }
      end
    else
      render json: { message: "Authentication failed." }
    end   
  end

  def destroy_mobile_devices
    if current_company.present?
      mobile_devices = MobileDevice.where(devicable_id: current_company.id)
      if mobile_devices.present?
        current_company.mobile_devices.destroy_all
        render json: { message: "mobile devices successfully destroyed" }
      else
        render json: { message: "company not have any mobile device" }
      end
    else
      render json: { message: "something went wrong" }
    end
  end
end