class Companies::OtpVerificationsController < ApiController
  before_action :find_company

  def verify_otp
    return render json: { message: "Company not found against given number" } unless @current_company.present?
    if @current_company.otp == params[:otp].to_i && @current_company.otp_expiry >= Time.current && params[:otp].present?
      @current_company.update(verified: true)
      return render json: { message: "otp verified" }
    else
      return render json: { message: 'otp not valid or present' }
    end
  end

  private

  def find_company
    @current_company = Company.find_by(phone_number: params[:phone_number])
  end
end