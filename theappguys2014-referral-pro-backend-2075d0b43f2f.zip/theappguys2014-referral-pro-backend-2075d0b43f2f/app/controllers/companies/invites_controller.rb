class Companies::InvitesController < ApiController
   before_action :authenticate_company!

   def create_invite
    if Invite.find_by(phone_number: params[:phone_number], company_id: current_company.id, status: 'created').present?
      render json: { message: "You have already invited this person" }
    else
      begin
        ActiveRecord::Base.transaction do
          @invite = current_company.invites.create(invite_params)
          TwilioService.new(@invite.phone_number, nil, @invite.company.name, nil, nil, nil).send_invite
        end
      rescue => e
        return render json: { message: e.error_message }
      end
      render json: { message: "Invite sent successfully", invite: @invite}
    end
  end

  def save_fcm_token
    if params[:token].present?
      token = current_company.mobile_devices.find_or_create_by(mobile_token: params[:token])
      render json: { message: "fcm token successfully saved", token: token }
    end  
  end

  private

  def invite_params
    params.permit(:name, :phone_number, :title)
  end
end