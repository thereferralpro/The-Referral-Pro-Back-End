class Companies::ReferralsController < ApiController
  before_action :authenticate_company!
  before_action :validate_referral_params, only: :create_referral

  def industry_user
    @company = Company.where.not(id: current_company.id).where(industry_id: params[:industry_id])
    @user = User.where.not(company_id: nil).where(industry_id: params[:industry_id])
    render json:{
      companies: ActiveModel::Serializer::CollectionSerializer.new(
        @company, 
        each_serializer: CompanySerializer,
        scope: current_company
      ),
      users: ActiveModel::Serializer::CollectionSerializer.new(
        @user, 
        each_serializer: UserSerializer,
        scope: current_company
      ),
     }
  end

  def create_partner
    if Partner.find_by(partnerable_id: current_company.id, partnered_id: params[:partnered_id], partnered_type: params[:partnered_type].capitalize).present?
      render json: { message: "Company already has this partner." }
    elsif params[:partnered_type].downcase == "user" && User.find_by(id: params[:partnered_id]).present?
      @partner = current_company.partners.create(partnered_id: params[:partnered_id], partnered_type: params[:partnered_type].capitalize)
      render json: @partner
    elsif params[:partnered_type].downcase == "company" && Company.find_by(id: params[:partnered_id]).present?
      @partner = current_company.partners.create(partnered_id: params[:partnered_id], partnered_type: params[:partnered_type].capitalize)
      render json: @partner
    else
      render json: { message: "User/Company is not present." }
    end
  end

  def create_referral
    phone_number = sync_contact(params[:contact_number])
    if params[:type] == 'company'
      begin 
        ActiveRecord::Base.transaction do
            @assigns = current_company.referral_assigns.create(
            company_id: params[:referrable_person_id],
            phone_number: phone_number,
            contact_name: params[:contact_name]
          )
          @referrable_company = Company.find_by(id: @assigns.company_id)
          TwilioService.new(@assigns.phone_number, nil, nil, params[:contact_name], current_company.name, nil).send_referral_assign
          TwilioService.new(current_company.phone_number, nil, nil, params[:contact_name], current_company.name, nil).send_referral_assign
          TwilioService.new(@referrable_company.phone_number, nil, nil, params[:contact_name], current_company.name, nil).send_referral_assign

        end
       rescue StandardError => e
        return render json: { message: e.error_message }
      end

      @referrable_person = Company.find_by(id: params[:referrable_person_id])
      @referrable_person_name = @referrable_person.name
      @industry_name = @referrable_person.industry.name 
      
      Notification.create(
        body: "Your referral to #{@industry_name} #{@referrable_person_name} assigned successfully",
        notifiable_id: current_company.id, notifiable_type: current_company.class.name
      )

      Notification.create(
        body: "You have been assigned a referral by #{current_company.name} for #{@industry_name} job",
        notifiable_id: @referrable_person.id, notifiable_type: @referrable_person.class.name
      )
      render json: @assigns
    else
      params[:contact_number] = phone_number
      begin
       ActiveRecord::Base.transaction do
         @referral = current_company.referrals.create(referral_params.merge(status: :created))
         @user = User.find_by(id: params[:referrable_person_id])
         TwilioService.new(@referral.contact_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral
         TwilioService.new(@referral.contact_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral_assign
         TwilioService.new(current_company.phone_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral_assign
         TwilioService.new(@user.phone_number, nil, nil, params[:contact_name], @user.name, @user.industry.name).send_referral_assign
        end
      rescue StandardError => e
        return render json: { message: e.error_message }
      end
     
      @referrable_person = User.find_by(id: params[:referrable_person_id])
      @referrable_person_name = @referrable_person.name
      @industry_name = @referrable_person.industry.name
      
      Notification.create(
        body: "Your referral to #{@industry_name} #{@referrable_person_name} sent successfully",
        notifiable_id: current_company.id, notifiable_type: current_company.class.name
      )

      Notification.create(
        #body: "You have been assigned a referral by #{current_company.name} for #{@industry_name} job",
        body: "You have a new referral.",
        notifiable_id: @referrable_person.id, notifiable_type: @referrable_person.class.name
      )
      if @referrable_person.company_id.present? && @referrable_person.company_id != current_company.id
        Notification.create(
          # body: "Your team member receives a new referral by #{current_user.name} for #{@industry_name} job",
          body: "Your team member #{@referrable_person_name} received a new referral",
          notifiable_id: @referrable_person.company_id, notifiable_type: 'Company'
        )
      end
      render json: @referral
    end
  end

  def received_referral
    var = current_company.referral_assignments.pluck(:referral_id)
    referrals = Referral.where(id: var)

    referral_assigns = current_company.referral_assignments.where(referral_id: nil)
    render json:{
      referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer),
      referral_assigns: ActiveModel::Serializer::CollectionSerializer.new(referral_assigns, each_serializer:ReferralAssignSerializer)
      }  
  end

  def sent_referral
    referrals = current_company.referrals
    var = current_company.referral_assigns.pluck(:referral_id)
    if var.present?
      referral_assigns = Referral.where(id: var).where.not(id: referrals.ids)
      return render json: {
        referrals: ActiveModel::Serializer::CollectionSerializer.new(
          referrals + referral_assigns,
          each_serializer: ReferralSerializer
        ),

        referral_assgins: ActiveModel::Serializer::CollectionSerializer.new(
          current_company.referral_assigns.where(referral_id: nil), 
          each_serializer: ReferralAssignSerializer
        )  
      }
    end

    render json: {
      referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer)
    }
  end

  def show_referrals_of_selected_company
    @user = User.find_by(id: params[:user_id]) if params[:user_id].present?
    if @user.present?
      if @user.company_id == current_company.id
        @sent_referrals = @user.referrals
        @recieved_referrals = @user.referred_persons
        render json: { message: "Referrals of selected user", sent_referrals:@sent_referrals,recieved_referrals: @recieved_referrals }
      else
        render json: { message: "Selected Rep is not in your team."}
      end
    else
      render json: { message: "user with this id is not present."}
    end
  end

  def show_referrals
    @company = Company.find_by(id: params[:id]) if params[:id].present?
    if @company.present?
      sent_referrals = @company.referrals
      var = @company.referral_assignments.pluck(:referral_id)
      recieved_referrals = Referral.where(id: var)
      render json:{
        message: "Referrals of selected company",
        sent_referrals: ActiveModel::Serializer::CollectionSerializer.new(sent_referrals, each_serializer: ReferralSerializer),
        recieved_referrals: ActiveModel::Serializer::CollectionSerializer.new(recieved_referrals, each_serializer: ReferralSerializer)
      }
    else
      render json:{ message: "company with this id is not present." }
    end
  end

  def filter_referrals
    referrals = []
    var = current_company.referral_assignments.pluck(:referral_id)
    if params[:status].present?  
      referrals = Referral.where(id: var, status: params[:status])
      if params[:status] == ["created"]
        referral_assigns = current_company.referral_assignments.where(referral_id: nil)
        return render json: {
          referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer),
          filter_referral_assigns: ActiveModel::Serializer::CollectionSerializer.new(referral_assigns, each_serializer:ReferralAssignSerializer)
        }
      end
      return render json: {
        referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer),
      }
    else
      referrals = Referral.where(id: var)
    end
      render json: {
        referrals: ActiveModel::Serializer::CollectionSerializer.new(referrals, each_serializer: ReferralSerializer),
      }
  end

  def sort_referrals
    var = current_company.referral_assignments.pluck(:referral_id)

   if params[:sort_by] == "newest_received"
     sorted_referrals = Referral.where(id: var).order("created_at DESC")
     sorted_referral_assigns = current_company.referral_assignments.where(referral_id: nil).order("created_at DESC") 

     render json: {
      sorted_referrals: ActiveModel::Serializer::CollectionSerializer.new(
        sorted_referrals, 
        each_serializer: ReferralSerializer
      ),
      sorted_referral_assigns: ActiveModel::Serializer::CollectionSerializer.new(
        sorted_referral_assigns,
        each_serializer:ReferralAssignSerializer
      )
    }

   else params[:sort_by] == "oldest_received"
     referrals = Referral.where(id: var).order("created_at ASC")
      sorted_referral_assigns = current_company.referral_assignments.where(referral_id: nil).order("created_at ASC") 

      render json: {
      referrals: ActiveModel::Serializer::CollectionSerializer.new(
        referrals,
        each_serializer: ReferralSerializer
      ),
      sorted_referral_assigns: ActiveModel::Serializer::CollectionSerializer.new(
        sorted_referral_assigns, 
        each_serializer:ReferralAssignSerializer
      )
    }
   end
  end

  def update_referral_status
    var = current_company.referral_assignments.pluck(:referral_id)
    referral = Referral.where(id: var)
    referral = referral.find_by(id: params[:id])
    return render json: { message: "Company received referral not found against given id" } unless referral.present?
    referral.update(status_params)
    
    if params[:status] == 'sold' || params[:status] == 'no_oportunity'
      Notification.create(
        # body: "Referral status changed to #{params[:status]}",
        body: "A team member has closed a referral as #{params[:status]}",
        notifiable_id: referral.referrable_id, notifiable_type: 'Company'
      ) 
    end
    render json: { message: "Updated successfully"}
  end

  def search_company_received_referrals
    if params[:name].present?
      referral_assigns = current_company.referral_assignments.select { |ref| ref.assignable.name.downcase.include? params[:name].downcase } 
      render json: { referal_assigns: ActiveModel::Serializer::CollectionSerializer.new(referral_assigns, each_serializer:ReferralAssignSerializer) }
    else
      render json: { referal_assigns: [] }
    end
  end

  private

  def validate_referral_params
    return render json: { message: "Type not found" } unless ['company', 'user'].include? params[:type]

    @type = params[:type].capitalize
    referred_person = @type.constantize.find_by(id: params[:referrable_person_id])

    if referred_person.blank?
      render json: { message: "#{@type} against this id is not present" }
    elsif params[:referrable_person_id].to_i == current_company.id && @type == "Company"
      render json: { message: "You cannot refer yourself"}
    elsif current_company.referrals.where(referrable_person: referred_person, contact_number: params[:contact_number]).any? && @type == "User"
      render json: { message: "#{@type} is already referred" }
    elsif referred_person.industry == nil
      render json: { message: "You should be industry professional"}
    end
  end

  def referral_params
    params.permit(:referrable_person_id, :contact_name, :contact_number, :contact_image)
  end

  def status_params
    params.permit(:status, :title)
  end
end