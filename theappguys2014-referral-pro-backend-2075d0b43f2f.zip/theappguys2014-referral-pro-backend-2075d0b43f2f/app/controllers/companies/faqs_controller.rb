class Companies::FaqsController < ApiController

  def index
    faqs = Faq.all
    render json: { message: "faqs", faqs: faqs}
  end
end