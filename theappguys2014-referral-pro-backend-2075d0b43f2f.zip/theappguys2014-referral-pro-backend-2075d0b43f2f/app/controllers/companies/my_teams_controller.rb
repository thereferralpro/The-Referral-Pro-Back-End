class Companies::MyTeamsController < ApiController
  before_action :authenticate_company!

  def my_team
    @teams = current_company.users.where(is_suspended: false)
    render json: {
      Team_members: ActiveModel::Serializer::CollectionSerializer.new(@teams, serializer: TeamSerializer)
    }
  end

  def my_partners
    @partners = current_company.partners
    render json: {
      partners: ActiveModel::Serializer::CollectionSerializer.new(@partners, serializer: PartnerSerializer)
    }
  end

  def get_company
    render json: {
       company: current_company,
       profile_image: current_company.image.attached? ? url_for(current_company.image) : ''
     }
   end

   def delete_company
     current_company.destroy
     render json: { message: "Company deleted successfully"}
   end
end
