class Companies::SocialNumbersController < ApiController
  before_action :authenticate_company!

  def add_phone_number
    if Company.find_by(phone_number: params[:phone_number]).present?
      render json: { message: "Phone number already belongs to another company"}
    elsif params[:phone_number].present?
      otp = (SecureRandom.random_number(9e3) + 1e3).to_i
      if ENV['USE_TWILIO'] == '0' 
        message = TwilioService.new(params[:phone_number], otp, nil, nil, nil, nil).send_otp
        raise 'Invalid phone number' unless message
      end
      current_company.update(otp: otp, otp_expiry:(Time.current + 2.minutes))
      render json: { message: "Please verify you phone number"}
    end
  end

  def resend_otp
    if params[:phone_number].present?
      otp = (SecureRandom.random_number(9e3) + 1e3).to_i
      if ENV['USE_TWILIO'] == '0'  
        message = TwilioService.new(params[:phone_number],otp, nil, nil, nil, nil).send_otp
        raise 'Invalid phone number' unless message
      end
      current_company.update(otp: otp, otp_expiry:(Time.current + 2.minutes))
      render json: { message: "Otp sent successfully", company: current_company}
    else
      render json: { message: "Please enter number for verification"}
    end
  end

  def otp_verification
    return render json: { message: "company not found " } unless current_company.present?
    if current_company.otp == params[:otp].to_i && current_company.otp_expiry >= Time.current && params[:otp].present? 
      current_company.update(verified: true)
      if current_company.verified == true 
        current_company.update(phone_number: params[:phone_number])
        render json: { message: "Phone number saved successfully" }
      end
    else
      return render json: { message: 'otp not valid or present' }
    end
  end
 end