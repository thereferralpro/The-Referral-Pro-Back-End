class Companies::AddToUsersController < ApiController
  before_action :authenticate_company!

  def add_user
    @user = User.find_by(id: params[:id])
    return render json: { message: "User not found against given id" } unless @user.present?

    if @user.is_suspended == false
      @user.update(company_id: current_company.id)
      render json: { message: "User added successfully in company" }
    else
       return render json: { message: "User is suspended" }
    end
  end

  def search_team_member
    @q = current_company.users.ransack("name_cont": params[:name])
    @results = @q.result(distinct: true)
    render json: {
      Search_Results: ActiveModel::Serializer::CollectionSerializer.new(@results, serializer: SearchTeamSerializer)
    }
  end
end
