class Companies::UserSuspendsController < ApiController
  before_action :authenticate_company!
  before_action :find_user

  def suspend_user
    return render json: { message: "User not found against given id" } unless @user.present?
    @user.update(is_suspended: true)
    render json: {message: "user successfully suspended"}
  end

  def remove_user
    return render json: { message: "User not found against given id" } unless @user.present?
    @user.update(company_id: nil)
    render json: {message: "user successfully removed"}
  end

  private

  def find_user
    @user = User.find_by(id: params[:id])
  end
end
