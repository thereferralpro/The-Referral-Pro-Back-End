class ResetPasswordsController < ApiController
  def forgot_password
    return render json: { message: "User not found against given number" } unless @resource.present?
    @resource.generate_otp
    return render json: { message: "reset password otp send successfully" }
  end

  def reset_verify_otp
    return render json: { message: "User not found against given number" } unless @resource.present?
    if @resource.otp == params[:otp].to_i && @resource.otp_expiry >= Time.current && params[:otp].present?
      @resource.update(verified: true)
      return render json: { message: "otp verified" }
    else
      return render json: { message: 'otp not valid or present' }
    end
  end

  def reset_password
    return render json: { message: "User not found against given number" } unless @resource.present?
    if @resource.update(password_params)
      return render json: { message: "password updated successfully" }
    else
      return render json: { message: "password not updated" }
    end
  end

  protected

  def define_resource(resource)
    @resource = resource
  end

  private

  def password_params
    params.permit(:password, :password_confirmation)
  end
end
