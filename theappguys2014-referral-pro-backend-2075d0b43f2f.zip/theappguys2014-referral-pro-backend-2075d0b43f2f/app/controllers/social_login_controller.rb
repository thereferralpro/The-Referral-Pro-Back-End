class SocialLoginController < ApiController
  def social_login
    return render json: { message: 'provider not specified' } unless ['google', 'apple', 'facebook'].include? params['provider']
    response = SocialLoginService.new(params['provider'], params['token'], params['type'], params['fcm_token']).social_login
    if params[:type] == "company" && response[0].present?
      transaction = response[0].transactions.order(:created_at).last
      subscription_ended = transaction.present? ? false : true
    end
    
    render json: { resource: response[0], token: response[1], profile_image: response[2], subscription_ended: subscription_ended }
  end
end
