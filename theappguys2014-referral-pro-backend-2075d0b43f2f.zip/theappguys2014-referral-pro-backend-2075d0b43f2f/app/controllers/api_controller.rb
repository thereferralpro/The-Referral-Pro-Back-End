class ApiController < ActionController::API

  protected

  def sync_contact(phone_no)
    if phone_no[0] != "+"
      phone_no = "+1#{phone_no}"
    end

    phone_no
  end
end
