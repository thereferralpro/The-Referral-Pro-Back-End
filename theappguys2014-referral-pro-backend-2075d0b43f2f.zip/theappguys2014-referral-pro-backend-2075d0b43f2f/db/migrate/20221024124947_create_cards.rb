class CreateCards < ActiveRecord::Migration[6.1]
  def change
    create_table :cards do |t|
      t.references :company
      t.string "token"
      t.string "card_holder_name"
      t.string "brand_name"
      t.integer "cvc"
      t.integer "expiry"
      t.string "expiry_month"
      t.string "country"
      t.string "city"
      t.boolean "default", default: false

      t.timestamps
    end
  end
end
