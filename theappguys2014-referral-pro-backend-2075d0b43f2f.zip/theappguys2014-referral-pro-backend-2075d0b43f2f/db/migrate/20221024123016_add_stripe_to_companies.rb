class AddStripeToCompanies < ActiveRecord::Migration[6.1]
  def change
    add_column :companies, :stripe_customer_id, :string
    add_column :companies, :stripe_connect_id, :string
  end
end
