class CreateReferral < ActiveRecord::Migration[6.1]
  def change
    create_table :referrals do |t|
      t.string :contact_number
      t.string :contact_name
      t.references :referrable, polymorphic: true
      t.references :referrable_person, polymorphic: true
      t.text :title
      t.integer :status,  default: 0
      t.timestamps
    end
  end
end
