class AddPhoneNumberToCompanies < ActiveRecord::Migration[6.1]
  def change
    add_column :companies, :phone_number, :string
    add_column :companies, :otp, :integer
    add_column :companies, :otp_expiry, :datetime
  end
end
