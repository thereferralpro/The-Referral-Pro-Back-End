class AddContactNameToReferralAssigns < ActiveRecord::Migration[6.1]
  def change
    add_column :referral_assigns, :contact_name, :string
  end
end
