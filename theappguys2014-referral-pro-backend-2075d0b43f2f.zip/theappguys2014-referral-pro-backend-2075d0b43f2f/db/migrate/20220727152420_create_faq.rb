class CreateFaq < ActiveRecord::Migration[6.1]
  def change
    create_table :faqs do |t|
      t.text :question, null: false
      t.text :answer, null: false
      t.integer :order, unique: true
      t.timestamps
    end
  end
end
