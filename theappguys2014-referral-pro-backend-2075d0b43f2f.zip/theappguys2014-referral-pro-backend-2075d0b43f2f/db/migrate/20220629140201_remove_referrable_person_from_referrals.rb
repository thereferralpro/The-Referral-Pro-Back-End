class RemoveReferrablePersonFromReferrals < ActiveRecord::Migration[6.1]
  def change
    remove_reference :referrals, :referrable_person, polymorphic: true
  end
end
