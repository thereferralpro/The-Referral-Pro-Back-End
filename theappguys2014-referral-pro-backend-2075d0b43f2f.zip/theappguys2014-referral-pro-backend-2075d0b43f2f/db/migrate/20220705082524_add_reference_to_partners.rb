class AddReferenceToPartners < ActiveRecord::Migration[6.1]
  def change
    add_reference :partners, :partnerable, polymorphic: true
  end
end
