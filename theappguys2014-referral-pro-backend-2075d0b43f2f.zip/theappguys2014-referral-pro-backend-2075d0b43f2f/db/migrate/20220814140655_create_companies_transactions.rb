class CreateCompaniesTransactions < ActiveRecord::Migration[6.1]
  def change
    create_table :transactions do |t|
      t.string :product_id
      t.datetime :transaction_date
      t.string :transaction_id
      t.text :transaction_receipt
      t.references :company

      t.timestamps
    end
  end
end
