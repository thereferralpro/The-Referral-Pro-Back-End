class CreateReferralAssigns < ActiveRecord::Migration[6.1]
  def change
    create_table :referral_assigns do |t|
      t.references :company
      t.references :assignable, polymorphic: true
      t.timestamps
    end
  end
end
