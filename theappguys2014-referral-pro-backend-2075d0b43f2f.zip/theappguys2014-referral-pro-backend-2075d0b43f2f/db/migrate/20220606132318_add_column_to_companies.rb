class AddColumnToCompanies < ActiveRecord::Migration[6.1]
  def change
    add_column :companies, :industry, :string
    add_column :companies, :name, :string 
    add_column :companies, :website, :string
    add_column :companies, :address, :string
    add_column :companies, :service_area, :string  
  end
end
