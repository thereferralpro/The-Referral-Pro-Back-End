class AddReferrablePersonInReferrals < ActiveRecord::Migration[6.1]
  def change
    add_reference :referrals, :referrable_person
  end
end
