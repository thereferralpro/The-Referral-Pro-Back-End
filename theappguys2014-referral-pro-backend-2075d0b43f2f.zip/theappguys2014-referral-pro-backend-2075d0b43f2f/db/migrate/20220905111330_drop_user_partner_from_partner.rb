class DropUserPartnerFromPartner < ActiveRecord::Migration[6.1]
  def change
    remove_column :partners, :user_partner_id
    add_reference :partners, :partnered, polymorphic: true
  end
end
