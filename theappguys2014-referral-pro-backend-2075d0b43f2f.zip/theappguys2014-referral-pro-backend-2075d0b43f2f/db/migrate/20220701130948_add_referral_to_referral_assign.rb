class AddReferralToReferralAssign < ActiveRecord::Migration[6.1]
  def change
    add_reference :referral_assigns, :referral
  end
end
