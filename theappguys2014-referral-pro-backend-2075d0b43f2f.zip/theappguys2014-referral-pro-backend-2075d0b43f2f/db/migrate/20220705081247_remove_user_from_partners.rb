class RemoveUserFromPartners < ActiveRecord::Migration[6.1]
  def change
    remove_reference :partners, :user
  end
end
