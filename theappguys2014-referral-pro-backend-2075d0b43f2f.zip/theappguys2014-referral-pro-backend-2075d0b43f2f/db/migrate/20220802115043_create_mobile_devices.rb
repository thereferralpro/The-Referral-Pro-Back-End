class CreateMobileDevices < ActiveRecord::Migration[6.1]
  def change
    create_table :mobile_devices do |t|
      t.string :mobile_token
      t.references :devicable, polymorphic: true
      t.timestamps
    end
  end
end
