# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2023_01_12_155641) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "active_storage_attachments", force: :cascade do |t|
    t.string "name", null: false
    t.string "record_type", null: false
    t.bigint "record_id", null: false
    t.bigint "blob_id", null: false
    t.datetime "created_at", null: false
    t.index ["blob_id"], name: "index_active_storage_attachments_on_blob_id"
    t.index ["record_type", "record_id", "name", "blob_id"], name: "index_active_storage_attachments_uniqueness", unique: true
  end

  create_table "active_storage_blobs", force: :cascade do |t|
    t.string "key", null: false
    t.string "filename", null: false
    t.string "content_type"
    t.text "metadata"
    t.string "service_name", null: false
    t.bigint "byte_size", null: false
    t.string "checksum", null: false
    t.datetime "created_at", null: false
    t.index ["key"], name: "index_active_storage_blobs_on_key", unique: true
  end

  create_table "active_storage_variant_records", force: :cascade do |t|
    t.bigint "blob_id", null: false
    t.string "variation_digest", null: false
    t.index ["blob_id", "variation_digest"], name: "index_active_storage_variant_records_uniqueness", unique: true
  end

  create_table "admins", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["email"], name: "index_admins_on_email", unique: true
    t.index ["reset_password_token"], name: "index_admins_on_reset_password_token", unique: true
  end

  create_table "cards", force: :cascade do |t|
    t.bigint "company_id"
    t.string "token"
    t.string "card_holder_name"
    t.string "brand_name"
    t.integer "cvc"
    t.integer "expiry"
    t.string "expiry_month"
    t.string "country"
    t.string "city"
    t.boolean "default", default: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["company_id"], name: "index_cards_on_company_id"
  end

  create_table "companies", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "industry"
    t.string "name"
    t.string "website"
    t.string "address"
    t.string "service_area"
    t.string "phone_number"
    t.integer "otp"
    t.datetime "otp_expiry"
    t.boolean "verified", default: false
    t.bigint "industry_id"
    t.string "description"
    t.string "stripe_customer_id"
    t.string "stripe_connect_id"
    t.index ["email"], name: "index_companies_on_email", unique: true
    t.index ["industry_id"], name: "index_companies_on_industry_id"
    t.index ["reset_password_token"], name: "index_companies_on_reset_password_token", unique: true
  end

  create_table "faqs", force: :cascade do |t|
    t.text "question", null: false
    t.text "answer", null: false
    t.integer "order"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.integer "position"
  end

  create_table "industries", force: :cascade do |t|
    t.string "name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "invites", force: :cascade do |t|
    t.string "name"
    t.string "phone_number"
    t.bigint "company_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.integer "status", default: 0
    t.string "title"
    t.index ["company_id"], name: "index_invites_on_company_id"
  end

  create_table "jwt_denylist", force: :cascade do |t|
    t.string "jti", null: false
    t.datetime "exp", null: false
    t.index ["jti"], name: "index_jwt_denylist_on_jti"
  end

  create_table "mobile_devices", force: :cascade do |t|
    t.string "mobile_token"
    t.string "devicable_type"
    t.bigint "devicable_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["devicable_type", "devicable_id"], name: "index_mobile_devices_on_devicable"
  end

  create_table "notifications", force: :cascade do |t|
    t.string "body"
    t.string "notifiable_type"
    t.bigint "notifiable_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["notifiable_type", "notifiable_id"], name: "index_notifications_on_notifiable"
  end

  create_table "partners", force: :cascade do |t|
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.string "partnerable_type"
    t.bigint "partnerable_id"
    t.string "partnered_type"
    t.bigint "partnered_id"
    t.index ["partnerable_type", "partnerable_id"], name: "index_partners_on_partnerable"
    t.index ["partnered_type", "partnered_id"], name: "index_partners_on_partnered"
  end

  create_table "privacy_policies", force: :cascade do |t|
    t.text "policy"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "referral_assigns", force: :cascade do |t|
    t.bigint "company_id"
    t.string "assignable_type"
    t.bigint "assignable_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "referral_id"
    t.string "phone_number"
    t.string "contact_name"
    t.index ["assignable_type", "assignable_id"], name: "index_referral_assigns_on_assignable"
    t.index ["company_id"], name: "index_referral_assigns_on_company_id"
    t.index ["referral_id"], name: "index_referral_assigns_on_referral_id"
  end

  create_table "referrals", force: :cascade do |t|
    t.string "contact_number"
    t.string "contact_name"
    t.string "referrable_type"
    t.bigint "referrable_id"
    t.text "title"
    t.integer "status", default: 0
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.bigint "referrable_person_id"
    t.index ["referrable_person_id"], name: "index_referrals_on_referrable_person_id"
    t.index ["referrable_type", "referrable_id"], name: "index_referrals_on_referrable"
  end

  create_table "transactions", force: :cascade do |t|
    t.string "product_id"
    t.datetime "transaction_date"
    t.string "transaction_id"
    t.text "transaction_receipt"
    t.bigint "company_id"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.integer "price"
    t.index ["company_id"], name: "index_transactions_on_company_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "name"
    t.string "phone_number"
    t.integer "otp"
    t.datetime "otp_expiry"
    t.string "industry"
    t.string "company_code"
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.boolean "is_suspended", default: false
    t.boolean "verified", default: false
    t.bigint "company_id"
    t.bigint "industry_id"
    t.string "description"
    t.datetime "joining_date"
    t.index ["company_id"], name: "index_users_on_company_id"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["industry_id"], name: "index_users_on_industry_id"
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  add_foreign_key "active_storage_attachments", "active_storage_blobs", column: "blob_id"
  add_foreign_key "active_storage_variant_records", "active_storage_blobs", column: "blob_id"
  add_foreign_key "companies", "industries"
  add_foreign_key "invites", "companies"
  add_foreign_key "users", "companies"
  add_foreign_key "users", "industries"
end
