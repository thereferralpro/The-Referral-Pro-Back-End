Ransack.configure do |c|
  # Change default search parameter key name.
  # Default key name is :q
   c.search_key = :name
end