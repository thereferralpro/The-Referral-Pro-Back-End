module.exports = {
    resolve: {
        alias: {
            jquery: 'jquery/src/jquery'
        }
    }
};
