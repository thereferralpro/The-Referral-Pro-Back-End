Rails.application.routes.draw do

  root to: "admins/manage_users#manage_user"
  namespace :admins do
    resources :faqs, only: [:index, :create, :new, :show ] do
      patch '/update_faq', to: 'faqs#update', as: :admin_faqs_update
      get '/delete_faq', to: 'faqs#destroy', as: :admin_faqs_delete
      get '/edit_faq', to: 'faqs#edit', as: :admin_faqs_edit
      member do
        patch :move
      end
    end 
    resources :users do
      member do
        get '/bio', to: 'users#user_bio'
        get '/sent_referrals', to: 'users#user_sent_referrals'
        get '/received_referrals', to: 'users#user_received_referrals'
      end
    end

    resources :industries
    
    resources :companies
    get '/otp_verification/index', to: 'otp_verifications#index'
    
    resources :manage_users do
      collection do
        get 'already_sign_in'
        get 'manage_faq'
        get 'financial_report'
        get 'manage_user'
        get 'companies'
      end
    end
  end
  get '/notifications/user_or_company_notifications', to: 'notifications#user_or_company_notifications', as: :user_or_company_notifications
  post '/notifications/destroy_notification', to: 'notifications#destroy_notification', as: :user_or_company_destroy_notifications

  devise_for :admins,
             controllers: {
                 sessions: 'admins/sessions',
                 passwords: 'admins/passwords'
             }
  post 'admins/otp_verification/verify_otp', to: 'admins/otp_verifications#verify_otp', as: :admin_verify_otp

  post 'social_login', to: 'social_login#social_login'
  devise_for :users, defaults: { format: :json },
             controllers: {
                 sessions: 'users/sessions',
                 registrations: 'users/registrations'
             }
  post 'user/verify_otp', to: 'users/otp_verifications#verify_otp'
  post 'user/forgot_password', to: 'users/reset_passwords#forgot_password'
  post 'user/forgot_password/verify_otp', to: 'users/reset_passwords#reset_verify_otp'
  post 'user/reset_password', to: 'users/reset_passwords#reset_password'
  post 'user/create_partner', to: 'users/partners#create_partner'
  post 'user/create_referral', to: 'users/referrals#create_referral'
  post 'user/sent_referral', to: 'users/referrals#sent_referral'
  post 'user/received_referral', to: 'users/referrals#received_referral'
  post 'user/all_industry', to: 'select_industries#all_industry'
  post 'user/industry_selection', to: 'users/select_industries#industry_selection'
  get  'user/search_industry', to: 'users/select_industries#search_industry'
  get  'user/industry_user', to: 'users/referrals#industry_user'
  get  'user/received_invites', to: 'users/partners#user_invites'
  post 'user/accept_invites', to: 'users/partners#accept_invites'
  post 'user/decline_invites', to: 'users/partners#decline_invites'
  get  'user/my_partners', to: 'users/partners#my_partners'
  get  'user/get_user', to: 'users/partners#get_user'
  post 'user/filter_referrals', to: 'users/referrals#filter_referrals'
  get  'user/sort_referrals', to: 'users/referrals#sort_referrals'
  put  'user/update_status', to: 'users/referrals#update_referral_status'
  post 'create_privacy_policy', to: 'users/privacy_policies#create_policy'
  put  'update_policy', to: 'users/privacy_policies#update_policy'
  get  'privacy_policy', to: 'users/privacy_policies#index'
  post 'user/add_phone_number', to: 'users/social_numbers#add_phone_number'
  post 'user/resend_otp', to: 'users/social_numbers#resend_otp'
  post 'user/otp_verification', to: 'users/social_numbers#otp_verification'
  get  'faq', to: 'companies/faqs#index'
  delete 'user/delete_user', to: 'users/partners#delete_user'
  get 'user/notifications/user_or_company_notifications', to: 'users/notifications#user_or_company_notifications', as: :users_user_or_company_notifications
  post 'user/notifications/destroy_notification', to: 'users/notifications#destroy_notification', as: :users_user_or_company_destroy_notifications
  post 'user/update_fcm_token', to: 'users/partners#save_fcm_token'
  delete 'user/destroy_tokens', to: 'users/notifications#destroy_mobile_devices'

  devise_for :companies,
               controllers: {
                   sessions: 'companies/sessions',
                   registrations: 'companies/registrations'
               }
  post  'company/verify_otp', to: 'companies/otp_verifications#verify_otp'
  post  'company/forgot_password', to: 'companies/reset_passwords#forgot_password'
  post  'company/forgot_password/verify_otp', to: 'companies/reset_passwords#reset_verify_otp'
  post  'company/reset_password', to: 'companies/reset_passwords#reset_password'
  post  'company/create_partner', to: 'companies/referrals#create_partner'
  post  'company/create_referral', to: 'companies/referrals#create_referral'
  post  'company/sent_referral', to: 'companies/referrals#sent_referral'
  post  'company/received_referral', to: 'companies/referrals#received_referral'
  post  'company/industry_selection', to: 'companies/select_industries#industry_selection'
  post  'company/referral_assign', to: 'companies/referral_assigns#referral_assign'
  post  'company/invite', to: 'companies/invites#create_invite'
  get   'company/industry_user', to: 'companies/referrals#industry_user'
  get   'company/my_team', to: 'companies/my_teams#my_team'
  get   'company/my_partners', to: 'companies/my_teams#my_partners'
  get   'company/add_user_to_company', to: 'companies/add_to_users#add_user'
  post   'company/referrals', to: 'companies/referrals#show_referrals_of_selected_company'
  post   'company/show_referrals', to: 'companies/referrals#show_referrals'
  get   'company/all_industry', to: 'select_industries#all_industry'
  get   'company/search_team_member', to: 'companies/add_to_users#search_team_member'
  put   'company/suspend_user', to:'companies/user_suspends#suspend_user'
  post   'company/filter_referrals', to: 'companies/referrals#filter_referrals'
  get   'company/sort_referrals', to: 'companies/referrals#sort_referrals'
  put   'company/update_status', to: 'companies/referrals#update_referral_status'
  get   'company/search_recieved_referrals', to: 'companies/referrals#search_company_received_referrals'
  delete 'company/remove_user', to:'companies/user_suspends#remove_user'
  post  'company/add_phone_number', to: 'companies/social_numbers#add_phone_number'
  post  'company/resend_otp', to: 'companies/social_numbers#resend_otp'
  post  'company/otp_verification', to: 'companies/social_numbers#otp_verification'
  get   'company/get_company', to: 'companies/my_teams#get_company'
  get  'company/search_industry', to: 'companies/select_industries#search_industry'
  delete 'company/delete_company', to: 'companies/my_teams#delete_company'
  get 'company/notifications/user_or_company_notifications', to: 'companies/notifications#user_or_company_notifications', as: :companies_user_or_company_notifications
  post 'company/notifications/destroy_notification', to: 'companies/notifications#destroy_notification', as: :companies_user_or_company_destroy_notifications
  post 'company/update_fcm_token', to: 'companies/invites#save_fcm_token'
  delete 'company/destroy_tokens', to: 'companies/notifications#destroy_mobile_devices'
  post  'company/add_card', to: 'companies/cards#add_card'
  get 'company/all_cards', to: 'companies/cards#all_cards'
  post 'company/edit_card', to: 'companies/cards#edit_card'
  delete 'company/delete_card', to: 'companies/cards#delete_card'
  get  'company/default_card', to: 'companies/cards#company_default_card'

  namespace :companies do
    resources :transactions, only: [:create, :index]
  end
end
